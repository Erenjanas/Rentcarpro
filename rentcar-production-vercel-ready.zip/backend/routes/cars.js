const router = require('express').Router();
const ctrl = require('../controllers/carController');
const { auth, adminOnly } = require('../middleware/auth');
router.get('/', ctrl.listCars);
router.get('/:id', ctrl.getCar);
router.post('/', auth, adminOnly, ctrl.createCar);
router.put('/:id', auth, adminOnly, ctrl.updateCar);
router.delete('/:id', auth, adminOnly, ctrl.deleteCar);
module.exports = router;
