
const app = require('../backend/server');
const { init } = require('../backend/db/database');

let initialized = false;

module.exports = async (req, res) => {
  if (!initialized) {
    await init();
    initialized = true;
  }
  return app(req, res);
};
